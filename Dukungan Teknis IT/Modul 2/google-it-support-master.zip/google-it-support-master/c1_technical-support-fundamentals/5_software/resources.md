## Resources

<br>

* https://en.wikipedia.org/wiki/Software_versioning