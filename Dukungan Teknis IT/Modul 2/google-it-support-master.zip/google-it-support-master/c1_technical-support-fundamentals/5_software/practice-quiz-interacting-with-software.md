## Interacting with Software

<br>

### Question 1

In the Linux distribution Ubuntu, what command would you use to install an application?

* **apt**
* execute
* application
* run

> apt is a command we use in Ubuntu for package installs.