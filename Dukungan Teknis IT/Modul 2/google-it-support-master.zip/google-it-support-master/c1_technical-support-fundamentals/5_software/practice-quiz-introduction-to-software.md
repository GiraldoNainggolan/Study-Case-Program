## Introduction to Software

<br>

### Question 1

Which of these is application software? Check all that apply.

* RAM
* **Web browser**
* **Email client**
* CPU

> Your web browser and email clients are considered application software.

### Question 2

Which of these is system software? Check all that apply.

* **Windows OS**
* **BIOS**
* CPU
* Text editor

> The Windows OS and the BIOS are considered system software.

### Question 3

What is the difference between an interpreted and a compiled language? Check all that apply

* **Interpreted languages are not broken into machine instructions beforehand.**
* Interpreted languages are broken into machine instructions beforehand.
* Compiled languages are not translated into machine instructions beforehand.
* **Compiled languages are translated into machine instructions beforehand.**

> Interpreted languages are not broken into machine instructions beforehand, like compiled languages are.