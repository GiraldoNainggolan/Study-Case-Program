## Computer Architecture

<br>

### Question 1

What are the four layers of the computer architecture?

* Hardware, Windows, Software, User
* Computer, Operating System, Software, User
* Binary, Hardware, Operating System, Software
* **Hardware, Operating System, Software, User**

> The layers of computer architecture are the hardware, operating system, software, and user layers.

<br>

### Question 2

Write a paragraph on examples of abstraction that you encounter in your day-to-day life. For example, driving a car is an example of abstraction, you don't need to understand how a car works underneath the hood in order to drive one.

```
Compiler is an example of abstraction, you don't need to understand how they convert your source code to a machine language
```