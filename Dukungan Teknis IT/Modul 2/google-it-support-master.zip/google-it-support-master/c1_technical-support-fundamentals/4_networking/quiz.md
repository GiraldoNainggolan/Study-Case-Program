## Course Quiz

<br>

### Basics of Networking

A(n) ______ is an interconnection of computers.

* service
* packet
* ethernet cable
* **network**

> You can connect many computers together to form a network.

In an IT field, managing, building, and designing networks is known as ______.

* coding
* **networking**
* engineering
* management

> The management and building of networks is known as networking.

<br>

### Internet of Things

True or false: The Internet of Things is a concept that's allowing more devices to be connected to the Internet.

* **True**
* False

> Common manual devices, like thermostats, kitchen appliances, and more, are being connected to the Internet thanks to the Internet of Things.