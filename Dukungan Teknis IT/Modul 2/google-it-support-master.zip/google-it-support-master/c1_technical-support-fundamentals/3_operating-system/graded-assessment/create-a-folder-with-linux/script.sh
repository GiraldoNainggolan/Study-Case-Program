#/usr/bin/bash

mkdir my-super-cool-folder