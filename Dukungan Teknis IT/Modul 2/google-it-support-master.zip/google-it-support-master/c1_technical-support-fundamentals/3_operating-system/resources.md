## Resources

<br>

* https://blogs.msdn.microsoft.com/powershell/2015/06/03/looking-forward-microsoft-support-for-secure-shell-ssh/
* https://en.wikipedia.org/wiki/Comparison_of_SSH_clients
* https://www.chiark.greenend.org.uk/~sgtatham/putty/latest.html
* https://en.wikipedia.org/wiki/Chrome_OS
* https://en.wikipedia.org/wiki/ReFS
* http://www.makeuseof.com/tag/operating-system-choose-next-pc/
* https://www.ubuntu.com/
* https://www.balena.io/etcher/
* https://www.ubuntuupdates.org/
* https://arstechnica.com/information-technology/2017/04/ubuntu-unity-is-dead-desktop-will-switch-back-to-gnome-next-year/