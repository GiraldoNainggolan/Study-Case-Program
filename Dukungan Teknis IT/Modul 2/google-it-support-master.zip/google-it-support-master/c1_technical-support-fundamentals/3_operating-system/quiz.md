### Logs

____ are files that record system events on our computer just like a system's diary. Check all that apply.

* Metadata
* Kernels
* **Logs**
* Bootloaders

> Logs are our computer's system diary.