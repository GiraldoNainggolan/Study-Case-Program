## The Modern Computer

<br>

### Question 1

Where does the CPU store its computations?

* Binary
* **Registers**
* Processor
* External Data Bus

> When the CPU does computation, it stores information in registers first.

<br>

### Question 2

Which mechanisms do we use to transport binary data and memory addresses? Check all that apply.

* **Address Bus**
* **The External Data Bus**
* School Bus
* DBus

> The EDB is used to transport binary data and the Address Bus is used to transport memory addresses.