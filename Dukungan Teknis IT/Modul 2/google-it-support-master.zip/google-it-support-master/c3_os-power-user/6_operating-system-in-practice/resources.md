## Resources

<br>

* https://blogs.msdn.microsoft.com/powershell/2015/06/03/looking-forward-microsoft-support-for-secure-shell-ssh/
* https://en.wikipedia.org/wiki/Comparison_of_SSH_clients
* https://www.chiark.greenend.org.uk/~sgtatham/putty/latest.html
* https://technet.microsoft.com/en-us/library/hh750728(v=ws.11).aspx
* https://en.wikipedia.org/wiki/Comparison_of_platform_virtualization_software
* https://www.virtualbox.org/manual/ch01.html
* https://en.wikipedia.org/wiki/Comparison_of_platform_virtualization_software
* http://manpages.ubuntu.com/manpages/zesty/man8/logrotate.8.html
* https://en.wikipedia.org/wiki/Comparison_of_disk_cloning_software
* http://man7.org/linux/man-pages/man1/dd.1.html