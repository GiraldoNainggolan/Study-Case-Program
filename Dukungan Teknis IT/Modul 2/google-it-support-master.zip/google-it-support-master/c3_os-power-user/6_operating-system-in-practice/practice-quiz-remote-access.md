## Remote Access

<br>

### Question 1

Which portion of the PuTTY package allows you to perform file transfers using the SCP (Secure Copy) protocol?

* **pscp.exe**
* psftp.exe
* pageant.exe

> The pscp.exe tool, or PuTTY Secure Copy Client, will let you copy files to and from remote computers using SCP.