## Resources

<br>

* https://msdn.microsoft.com/en-us/library/cc875839.aspx
* https://support.apple.com/HT201320
* https://support.google.com/nexus/answer/7664951
* https://support.google.com/nexus/answer/2865483
* https://msdn.microsoft.com/en-us/library/windows/desktop/aa374872(v=vs.85).aspx
* https://technet.microsoft.com/en-us/library/cc732880(v=ws.11).aspx