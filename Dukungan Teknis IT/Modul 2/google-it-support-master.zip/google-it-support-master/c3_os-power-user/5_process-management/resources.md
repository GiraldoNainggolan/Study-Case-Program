## Resources

<br>

* https://docs.microsoft.com/en-us/windows-server/administration/windows-commands/taskkill
* https://docs.microsoft.com/en-us/powershell/module/microsoft.powershell.management/get-process?view=powershell-5.1
* http://man7.org/linux/man-pages/man1/ps.1.html
* https://docs.microsoft.com/en-us/cpp/c-runtime-library/reference/signal
* https://docs.microsoft.com/en-us/sysinternals/downloads/process-explorer
* https://docs.microsoft.com/en-us/powershell/module/microsoft.powershell.management/get-process?view=powershell-5.1#outputs
* https://en.wikipedia.org/wiki/Load_(computing)