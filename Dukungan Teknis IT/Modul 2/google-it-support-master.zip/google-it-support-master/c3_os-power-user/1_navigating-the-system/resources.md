## Resources

<br>

* https://docs.microsoft.com/powershell/
* https://docs.microsoft.com/powershell/scripting/learn/ps101/00-introduction
* https://docs.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands
* https://www.gnu.org/software/bash/manual/bash.html
* https://technet.microsoft.com/en-us/library/hh148159.aspx
* https://notepad-plus-plus.org/
* https://www.nano-editor.org/
* https://vim.sourceforge.io/docs.php
* https://www.gnu.org/software/emacs/tour/
* https://mva.microsoft.com/en-us/training-courses/getting-started-with-microsoft-powershell-8276
* https://github.com/PowerShell/PowerShell/blob/master/docs/learning-powershell/README.md