## Resources

<br>

* https://en.wikipedia.org/wiki/Portable_Executable
* https://msdn.microsoft.com/en-us/library/windows/desktop/aa369294(v=vs.85).aspx
* https://en.wikipedia.org/wiki/Windows_Store
* https://msdn.microsoft.com/en-us/library/windows/desktop/hh446767(v=vs.85).aspx
* https://support.microsoft.com/en-us/help/912203/description-of-the-command-line-switches-that-are-supported-by-a-softw
* https://developer.apple.com/business/custom-apps/
* https://developers.google.com/android/work/play/custom-app-api/get-started
* https://docs.microsoft.com/en-us/powershell/module/microsoft.powershell.archive/compress-archive?view=powershell-5.0
* http://www.linfo.org/tar.html
* https://en.wikipedia.org/wiki/Dynamic-link_library
* https://en.wikipedia.org/wiki/DLL_Hell
* https://msdn.microsoft.com/en-us/library/aa376307.aspx
* http://www.powershellgallery.com/
* https://help.ubuntu.com/lts/serverguide/dpkg.html
* https://en.wikipedia.org/wiki/NuGet
* https://chocolatey.org/packages
* https://help.launchpad.net/Packaging/PPA
* https://docs.microsoft.com/en-us/sysinternals/downloads/procmon
* https://msdn.microsoft.com/en-us/library/windows/desktop/aa372837(v=vs.85).aspx
* https://msdn.microsoft.com/en-us/library/windows/desktop/aa370557(v=vs.85).aspx
* https://docs.microsoft.com/en-us/windows-hardware/drivers/kernel/introduction-to-plug-and-play
* https://docs.microsoft.com/en-us/windows-hardware/drivers/install/step-1--the-new-device-is-identified
* https://docs.microsoft.com/en-us/windows-hardware/drivers/install/hardware-ids
* https://docs.microsoft.com/en-us/windows-hardware/drivers/install/step-2--a-driver-for-the-device-is-selected
* https://en.wikipedia.org/wiki/Device_file
* https://en.wikipedia.org/wiki/Udev
* https://en.wikipedia.org/wiki/Windows_Update
* https://en.wikipedia.org/wiki/Linux_kernel
* https://www.linux.com/learn/linux-101-updating-your-system