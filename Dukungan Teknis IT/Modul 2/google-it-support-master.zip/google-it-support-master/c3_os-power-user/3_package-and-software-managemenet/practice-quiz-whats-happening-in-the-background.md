## What’s happening in the background?

<br>

### Question 1

Which of the following tools allows you to create or edit MSI files?

* Process monitor
* **Orca**
* Setup.exe

> The Orca tool, that's part of the Windows SDK, will let you work with MSI files. 