## VPNs & Proxies

<br>

### Question 1

Two-factor authentication is_________________________.

* a method where you need two passwords.
* a method that requires two usernames.
* a method where you authenticate twice.
* **a method where you need more than a username and a password.**

> Two-factor authentication requires a username/password and something extra.

<br>

### Question 2

VPNs are known as a _____ protocol.

* connectionless
* data link layer
* **tunneling**
* network layer

> VPNs are tunneling protocols.

<br>

### Question 3

A proxy is something that _______________________.

* sends data across a single network segment.
* **communicates on behalf of something else.**
* encrypts traffic sent across the Internet.
* allows for many devices to speak to one other device.

> While proxies are many things, they primarily communicate on behalf of something else.