## Resources

<br>

* https://www.iana.org/
* https://www.nro.net/ipv4-free-pool-depleted
* https://mailman.apnic.net/mailing-lists/apnic-announce/archive/2011/04/msg00002.html
* https://www.ripe.net/publications/news/announcements/ripe-ncc-begins-to-allocate-ipv4-address-space-from-the-last-8
* https://www.lacnic.net/en/web/anuncios/2014-no-hay-mas-direcciones-ipv4-en-lac
* https://www.arin.net/vault/announcements/2015/20150924.html
* https://afrinic.net/exhaustion
* https://en.wikipedia.org/wiki/IPv4_address_exhaustion