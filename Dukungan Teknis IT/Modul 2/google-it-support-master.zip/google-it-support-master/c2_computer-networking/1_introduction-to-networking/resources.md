## Resources

<br>

* https://www.sans.org/reading-room/whitepapers/standards/osi-model-overview-543
* https://en.wikipedia.org/wiki/OSI_model
* https://en.wikipedia.org/wiki/Ethernet_over_twisted_pair