## TCP/IP

<br>

### Question 1

Which of the following is an example of a network layer (layer 3) protocol?

* Ethernet
* **IP**
* UDP
* TCP

> IP, or Internet Protocol, is the most common network layer protocol.

<br>

### Question 2

What's the difference between a client and a server?

* Clients and servers are different names for the same thing.
* A server requests data, and a client responds to that request.
* Clients operate on the data link layer, and servers operate on the network layer.
* **A client requests data, and a server responds to that request.**

<br>

### Question 3

Which of the following are examples of layers of our five-layer network model? Check all that apply.

* **The physical layer**
* **The application layer**
* The presentation layer
* **The transport layer**