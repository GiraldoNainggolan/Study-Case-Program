## WANs

<br>

### Question 1

WAN stands for ______________.

* **Wide Area Network.**
* Wired Area Network.
* Wireless Area Network.
* Wireless Local Area Network.

> WAN stands for Wide Area Network.

<br>

### Question 2

In a WAN, the area between a demarcation point and the ISP's core network is known as ___________.

* an access point
* **a local loop**
* a Local Area Network
* a local link

> A local loop is the name for the area between a demarcation point and an ISP's network.

<br>

### Question 3

A point-to-point VPN is also known as a ______________.

* **site-to-site VPN**
* one-to-many VPN
* port forwarding VPN
* data link VPN

> A point-to-point VPN can also be referred to as a site-to-site VPN.