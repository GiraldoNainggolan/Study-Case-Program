## Broadband Internet

<br>

### Question 1

T1 is short for __________.

* Transportation System 1.
* **Transmission System 1.**
* Transportation 1.
* Transmission 1.

> T1 is short for Transmission System 1.

<br>

### Question 2

How fast is a T1 line?

* **1.544 Mb/sec**
* 44.763 Mb/sec
* 1 Mb/sec
* 128 Mb/sec

> A T1 communicates at speeds of 1.544 Kb/sec.

<br>

### Question 3

Select all statements that are true of cable internet connections.

* **They're broadband connections.**
* They're dial-up connections.
* **They're shared bandwidth connections.**
* They're wireless connections.