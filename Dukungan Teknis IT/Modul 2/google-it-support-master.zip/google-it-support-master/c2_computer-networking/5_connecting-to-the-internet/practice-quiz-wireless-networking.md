## Wireless Networking

<br>

### Question 1

How many address fields does an 802.11 header have?

* 1
* 2
* 3
* **4**

> There are four different address fields in an 802.11 header.

<br>

### Question 2

A wireless channel is ____________.

* **a portion of a frequency band.**
* a point-to-point wireless connection.
* a collision domain.
* an example of an ad-hoc network.

> A channel represents a portion of a frequency band.

<br>

### Question 3

Choose all of the frequencies that wireless networks typically operate on.

* 88Mhz
* 1.544Ghz
* **2.4Ghz**
* **5Ghz**