## Resources

<br>

* https://en.wikipedia.org/wiki/Point-to-Point_Protocol
* https://tools.ietf.org/html/rfc1661
* https://en.wikipedia.org/wiki/Point-to-point_protocol_over_Ethernet
* https://tools.ietf.org/html/rfc2516
* https://en.wikipedia.org/wiki/High-Level_Data_Link_Control
* https://en.wikipedia.org/wiki/High-Level_Data_Link_Control
* https://en.wikipedia.org/wiki/Asynchronous_Transfer_Mode
* https://en.wikipedia.org/wiki/IEEE_802.11
* https://en.wikipedia.org/wiki/Internet_of_things
* https://z-wavealliance.org/about_z-wave_technology/
* https://z-wavealliance.org/about_z-wave_technology/
* https://zigbee.org/zigbee-for-developers/zigbee-3-0/
* https://www.threadgroup.org/What-is-Thread