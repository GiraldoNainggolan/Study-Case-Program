## POTS and Dial-up

<br>

### Question 1

Another term for POTS, or the Plain Old Telephone System, is _______________.

* **Public Switched Telephone Network.**
* Phone Switched Transport Network.
* Public Switched Telephone Exchange.
* Public Available Telephone Network.
* Public Available Telephone Exchange.

> POTS and PSTN refer to the same thing.

<br>

### Question 2

A baud rate is a measurement of the number of ______________________.

* data segments that can be sent across a telephone line every second.
* **bits that can be sent across a telephone line every second.**
* bytes that can be sent across a telephone line every second.
* packets that can be sent across a telephone line every second.

> A baud rate is equivalent to bits per second.