## Resources

<br>

* https://github.com/rsyslog/rsyslog
* https://www.splunk.com/
* https://www.ibm.com/security/security-intelligence/qradar
* https://community.rsa.com/docs/DOC-41639
* http://itknowledgeexchange.techtarget.com/security-corner/whats-your-systems-survival-time/
* http://robert.ocallahan.org/2017/01/disable-your-antivirus-software-except.html
* http://lock.cmpxchg8b.com/Sophail.pdf
* http://www.crn.com/news/security/240148192/bit9-admits-systems-breach-stolen-code-signing-certificates.htm
* https://docs.microsoft.com/en-us/windows/security/information-protection/bitlocker/bitlocker-overview
* https://support.apple.com/en-us/HT204837
* https://wiki.archlinux.org/index.php/dm-crypt
* https://www.symantec.com/products/encryption
* http://truecrypt.sourceforge.net/
* https://www.veracrypt.fr/en/Home.html