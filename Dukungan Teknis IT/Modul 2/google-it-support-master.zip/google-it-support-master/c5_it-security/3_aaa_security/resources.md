## Resources

<br>

* https://www.planetbiometrics.com/article-details/i/5774/desc/indian-pupils-cheat-biometric-system-with-glue/
* https://www.theverge.com/2017/5/3/15534768/google-docs-phishing-attack-share-this-document-with-you-spam