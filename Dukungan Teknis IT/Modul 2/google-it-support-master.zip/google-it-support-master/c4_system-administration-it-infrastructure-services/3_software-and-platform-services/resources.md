## Resources

<br>

* https://zapier.com/blog/best-team-chat-app/
* https://www.digitalocean.com/community/tutorials/why-you-may-not-want-to-run-your-own-mail-server
* https://blog.servermania.com/what-protocols-send-receive-email-with-the-mail-server/
* https://technet.microsoft.com/en-us/library/hh831795(v=ws.11).aspx
* http://www.linuxfromscratch.org/blfs/view/cvs/basicnet/nfs-utils.html
* https://en.wikipedia.org/wiki/Inkjet_printing
* https://computer.howstuffworks.com/inkjet-printer.htm
* https://support.microsoft.com/help/4028622/windows-10-how-to-set-a-default-printer
* https://support.apple.com/guide/mac-help/change-default-printer-a-printers-mac-mchlp1036/mac
* https://help.ubuntu.com/stable/ubuntu-help/printing-setup-default-printer.html
* https://docs.microsoft.com/en-us/previous-versions/windows/it-pro/windows-server-2012-r2-and-2012/hh831468(v=ws.11)
* https://help.ubuntu.com/lts/serverguide/cups.html
* https://stackshare.io/stackups/apache-httpd-vs-microsoft-iis-vs-nginx
* https://www.bls.gov/ooh/computer-and-information-technology/database-administrators.htm
* https://www.digitalocean.com/community/tutorials/sqlite-vs-mysql-vs-postgresql-a-comparison-of-relational-database-management-systems
* https://developer.chrome.com/devtools
* https://en.wikipedia.org/wiki/List_of_HTTP_status_codes
* https://azure.microsoft.com/en-us/overview/what-is-cloud-computing/
* https://aws.amazon.com/getting-started/
* https://cloud.google.com/docs/overview/